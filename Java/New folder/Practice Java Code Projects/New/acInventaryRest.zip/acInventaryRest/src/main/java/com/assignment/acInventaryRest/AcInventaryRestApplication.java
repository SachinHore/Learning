package com.assignment.acInventaryRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcInventaryRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcInventaryRestApplication.class, args);
	}

}
