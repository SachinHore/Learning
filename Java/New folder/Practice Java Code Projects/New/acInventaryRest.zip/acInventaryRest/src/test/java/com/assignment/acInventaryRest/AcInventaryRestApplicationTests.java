package com.assignment.acInventaryRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcInventaryRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
